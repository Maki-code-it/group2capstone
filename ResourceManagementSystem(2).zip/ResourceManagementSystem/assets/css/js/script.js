document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Show notifications
    if (document.getElementById('liveToast')) {
        var toastEl = document.getElementById('liveToast');
        var toast = new bootstrap.Toast(toastEl);
        toast.show();
    }
    
    // Initialize skill inputs
    initSkillInput();
});

function initSkillInput() {
    const skillInputs = document.querySelectorAll('.skill-input');
    
    skillInputs.forEach(input => {
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                const value = this.value.trim();
                
                if (value) {
                    addSkillTag(value, this);
                    this.value = '';
                }
            }
        });
        
        input.addEventListener('blur', function() {
            const value = this.value.trim();
            if (value) {
                addSkillTag(value, this);
                this.value = '';
            }
        });
    });
}

function addSkillTag(skill, input) {
    const container = input.parentNode.querySelector('.skill-tags');
    if (!container) return;
    
    // Check if skill already exists
    const existingSkills = container.querySelectorAll('.skill-tag');
    for (let tag of existingSkills) {
        if (tag.textContent.replace('×', '').trim() === skill) return;
    }
    
    const tag = document.createElement('span');
    tag.className = 'skill-tag badge bg-primary me-1 mb-1';
    tag.innerHTML = skill + '<input type="hidden" name="skills[]" value="' + skill + '">';
    
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'btn-close btn-close-white ms-1';
    removeBtn.style.fontSize = '0.6rem';
    removeBtn.onclick = function() {
        tag.remove();
    };
    
    tag.appendChild(removeBtn);
    container.appendChild(tag);
}