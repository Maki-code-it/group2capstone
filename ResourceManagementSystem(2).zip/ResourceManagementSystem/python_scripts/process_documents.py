import sys
import pytesseract
from PIL import Image
import PyPDF2
import mysql.connector
import re

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="resource_management"
)

def extract_text_from_pdf(pdf_path):
    """Extract text from PDF file"""
    text = ""
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() + "\n"
    except Exception as e:
        print(f"Error extracting text from PDF: {e}")
    return text

def extract_text_from_image(image_path):
    """Extract text from image using Tesseract OCR"""
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        return text
    except Exception as e:
        print(f"Error extracting text from image: {e}")
        return ""

def extract_skills_from_text(text):
    """Extract skills from text using regex patterns"""
    skills = []
    
    # Common skills patterns
    skill_patterns = [
        r'python', r'java', r'sql', r'javascript', r'html', r'css', r'react', r'node\.js',
        r'machine learning', r'data analysis', r'project management', r'communication',
        r'problem solving', r'teamwork', r'leadership', r'time management', r'aws', r'azure',
        r'docker', r'kubernetes', r'jenkins', r'git', r'ci/cd', r'agile', r'scrum'
    ]
    
    text_lower = text.lower()
    for pattern in skill_patterns:
        if re.search(pattern, text_lower):
            skills.append(pattern)
    
    return list(set(skills))

def update_employee_skills(employee_id, new_skills):
    """Update employee skills in database"""
    cursor = db.cursor()
    
    # Get existing skills
    cursor.execute("SELECT skills FROM employees WHERE user_id = %s", (employee_id,))
    result = cursor.fetchone()
    existing_skills = result[0].split(',') if result and result[0] else []
    
    # Combine and deduplicate skills
    all_skills = list(set([s.strip() for s in existing_skills + new_skills if s.strip()]))
    skills_str = ','.join(all_skills)
    
    # Update database
    cursor.execute("UPDATE employees SET skills = %s WHERE user_id = %s", (skills_str, employee_id))
    db.commit()
    cursor.close()

def main():
    if len(sys.argv) < 3:
        print("Usage: python process_documents.py <employee_id> <file_path>")
        return
    
    employee_id = sys.argv[1]
    file_path = sys.argv[2]
    
    # Determine file type and extract text accordingly
    if file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp')):
        extracted_text = extract_text_from_image(file_path)
    elif file_path.lower().endswith('.pdf'):
        extracted_text = extract_text_from_pdf(file_path)
    else:
        print(f"Unsupported file format: {file_path}")
        return
    
    # Extract skills from text
    skills = extract_skills_from_text(extracted_text)
    
    # Update employee skills in database
    if skills:
        update_employee_skills(employee_id, skills)
    
    # Store extracted text in database
    cursor = db.cursor()
    sql = "INSERT INTO certificates (employee_id, file_path, extracted_text) VALUES (%s, %s, %s)"
    values = (employee_id, file_path, extracted_text)
    cursor.execute(sql, values)
    db.commit()
    cursor.close()
    
    print(f"Successfully processed document: {file_path}")
    print(f"Extracted skills: {', '.join(skills)}")

if __name__ == "__main__":
    main()