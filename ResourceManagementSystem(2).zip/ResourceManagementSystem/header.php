<?php
// header.php
$current_file = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resource Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-users-cog me-2"></i>
                <strong>Resource Management System</strong>
            </a>
            <?php if (isset($_SESSION['user_id'])): ?>
            <div class="d-flex align-items-center">
                <span class="navbar-text me-3">
                    <i class="fas fa-user-circle me-1"></i>
                    <?php echo $_SESSION['name']; ?> (<?php echo ucfirst(str_replace('_', ' ', $_SESSION['role'])); ?>)
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
            <?php endif; ?>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <?php if (isset($_SESSION['user_id'])): ?>
            <div class="col-lg-2 col-md-3 p-0 sidebar">
                <div class="p-3 text-center">
                    <div class="rounded-circle bg-light d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                        <i class="fas fa-user text-primary" style="font-size: 2rem;"></i>
                    </div>
                    <h6 class="mt-2 mb-0"><?php echo $_SESSION['name']; ?></h6>
                    <small class="text-light"><?php echo ucfirst(str_replace('_', ' ', $_SESSION['role'])); ?></small>
                </div>
                <hr class="my-2 bg-light">
                <nav class="nav flex-column">
                    <?php if ($_SESSION['role'] == 'hr_admin'): ?>
                        <a class="nav-link <?php echo $current_file == 'index.php' ? 'active' : ''; ?>" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link <?php echo $current_file == 'create_user.php' ? 'active' : ''; ?>" href="create_user.php">
                            <i class="fas fa-user-plus me-2"></i>Create Users
                        </a>
                    <?php elseif ($_SESSION['role'] == 'project_manager'): ?>
                        <a class="nav-link <?php echo $current_file == 'index.php' ? 'active' : ''; ?>" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    <?php elseif ($_SESSION['role'] == 'employee'): ?>
                        <a class="nav-link <?php echo $current_file == 'index.php' ? 'active' : ''; ?>" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    <?php endif; ?>
                </nav>
            </div>
            <div class="col-lg-10 col-md-9 p-4">
            <?php endif; ?>