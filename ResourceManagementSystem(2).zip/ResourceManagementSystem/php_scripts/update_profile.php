<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['role'] == 'employee') {
    $user_id = $_SESSION['user_id'];
    $skills = $conn->real_escape_string(implode(',', $_POST['skills']));
    $education = $conn->real_escape_string($_POST['education']);
    
    $sql = "UPDATE employees SET skills = '$skills', education = '$education' WHERE user_id = $user_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Profile updated successfully!";
    } else {
        $_SESSION['error'] = "Error updating profile: " . $conn->error;
    }
    
    header("Location: ../index.php");
    exit();
} else {
    header("Location: ../login.php");
    exit();
}
?>