<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['role'] == 'employee') {
    $user_id = $_SESSION['user_id'];
    
    // File upload handling
    $upload_dir = '../uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_name = time() . '_' . basename($_FILES['certificate']['name']);
    $file_path = $upload_dir . $file_name;
    
    // Check if file is a valid PDF or image
    $file_type = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    $allowed_types = array('pdf', 'jpg', 'jpeg', 'png');
    
    if (!in_array($file_type, $allowed_types)) {
        $_SESSION['error'] = "Only PDF, JPG, JPEG, PNG files are allowed.";
        header("Location: ../index.php");
        exit();
    }
    
    // Move uploaded file
    if (move_uploaded_file($_FILES['certificate']['tmp_name'], $file_path)) {
        // Call Python OCR script to process the document
        $escaped_file_path = escapeshellarg($file_path);
        $escaped_user_id = escapeshellarg($user_id);
        $python_script = "../python_scripts/process_documents.py";
        $command = "python $python_script $escaped_user_id $escaped_file_path 2>&1";
        $output = shell_exec($command);
        
        error_log("Python OCR Output: " . $output);
        
        $_SESSION['message'] = "Certificate uploaded successfully!";
    } else {
        $_SESSION['error'] = "Error uploading file.";
    }
    
    header("Location: ../index.php");
    exit();
} else {
    header("Location: ../login.php");
    exit();
}
?>