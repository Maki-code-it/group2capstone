<?php
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'hr_admin') {
    header("Location: login.php");
    exit();
}
?>
<?php include 'header.php'; ?>

<h2 class="mb-4"><i class="fas fa-user-plus me-2"></i>Create New User</h2>

<div class="row">
    <div class="col-md-8">
        <div class="blue-card card">
            <div class="card-header">
                <h5 class="mb-0">User Information</h5>
            </div>
            <div class="card-body">
                <form action="php_scripts/create_user.php" method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="">Select Role</option>
                                <option value="hr_admin">HR Admin</option>
                                <option value="project_manager">Project Manager</option>
                                <option value="employee">Employee</option>
                            </select>
                        </div>
                    </div>
                    
                    <div id="employeeFields" style="display: none;">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="department" class="form-label">Department</label>
                                <input type="text" class="form-control" id="department" name="department">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="skills" class="form-label">Skills</label>
                            <div class="skill-tags-container border rounded p-2">
                                <div class="skill-tags mb-2"></div>
                                <input type="text" class="form-control skill-input" placeholder="Type skill and press Enter">
                            </div>
                            <small class="form-text text-muted">Press Enter or comma to add multiple skills</small>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-user-plus me-2"></i>Create User
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="blue-card card">
            <div class="card-header">
                <h5 class="mb-0">User Management</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="#" class="btn btn-outline-primary mb-2">
                        <i class="fas fa-list me-2"></i>View All Users
                    </a>
                    <a href="#" class="btn btn-outline-primary mb-2">
                        <i class="fas fa-file-export me-2"></i>Export Users
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('role').addEventListener('change', function() {
    const employeeFields = document.getElementById('employeeFields');
    employeeFields.style.display = this.value === 'employee' ? 'block' : 'none';
});
</script>

<?php include 'footer.php'; ?>

<?php
include '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'hr_admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $conn->real_escape_string($_POST['role']);
    $department = isset($_POST['department']) ? $conn->real_escape_string($_POST['department']) : '';
    $skills = isset($_POST['skills']) ? implode(',', $_POST['skills']) : '';
    
    // Insert user
    $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";
    
    if ($conn->query($sql)) {
        $user_id = $conn->insert_id;
        
        // If employee, create employee record
        if ($role == 'employee') {
            $sql = "INSERT INTO employees (user_id, department, skills) VALUES ($user_id, '$department', '$skills')";
            $conn->query($sql);
        }
        
        $_SESSION['message'] = "User created successfully!";
    } else {
        $_SESSION['error'] = "Error creating user: " . $conn->error;
    }
    
    header("Location: ../index.php");
    exit();
} else {
    header("Location: ../index.php");
    exit();
}
?>