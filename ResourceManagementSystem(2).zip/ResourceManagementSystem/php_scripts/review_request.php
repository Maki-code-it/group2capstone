<?php
include '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'hr_admin') {
    header("Location: ../login.php");
    exit();
}

$request_id = $_GET['request_id'];
$sql = "SELECT * FROM project_requests WHERE id = $request_id";
$result = $conn->query($sql);
$request = $result->fetch_assoc();

// Get AI recommendations by calling Python script
$skills_required = escapeshellarg($request['required_skills']);
$python_script = "../python_scripts/get_recommendations.py";
$command = "python $python_script $skills_required 2>&1";
$output = shell_exec($command);
$recommendations = json_decode($output, true);

// If we got recommendations, display them
if (is_array($recommendations)) {
    // Save recommendations to database
    foreach ($recommendations as $index => $employee) {
        $employee_id = $employee['id'];
        $score = $employee['score'];
        $sql = "INSERT INTO ai_recommendations (request_id, employee_id, score, rank) 
                VALUES ($request_id, $employee_id, $score, $index+1) 
                ON DUPLICATE KEY UPDATE score = $score, rank = $index+1";
        $conn->query($sql);
    }
}
?>
<?php include '../header.php'; ?>

<h2 class="mb-4"><i class="fas fa-search me-2"></i>Review Project Request</h2>

<div class="row">
    <div class="col-md-12">
        <div class="blue-card card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Project Details</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Project Name:</strong> <?php echo $request['project_name']; ?></p>
                        <p><strong>Skills Required:</strong> <?php echo $request['required_skills']; ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Employees Needed:</strong> <?php echo $request['employees_needed']; ?></p>
                        <p><strong>Duration:</strong> <?php echo $request['duration']; ?> days</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="blue-card card">
            <div class="card-header">
                <h5 class="mb-0">AI Recommendations</h5>
            </div>
            <div class="card-body">
                <?php if (is_array($recommendations) && count($recommendations) > 0): ?>
                    <form action="assign_employees.php" method="POST">
                        <input type="hidden" name="request_id" value="<?php echo $request_id; ?>">
                        
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Select</th>
                                        <th>Rank</th>
                                        <th>Employee Name</th>
                                        <th>Skills</th>
                                        <th>Match Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recommendations as $index => $employee): ?>
                                        <tr>
                                            <td>
                                                <input class="form-check-input" type="checkbox" name="employees[]" value="<?php echo $employee['id']; ?>" 
                                                    <?php echo $index < $request['employees_needed'] ? 'checked' : ''; ?>>
                                            </td>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo $employee['name']; ?></td>
                                            <td><?php echo $employee['skills']; ?></td>
                                            <td>
                                                <div class="progress" style="height: 20px;">
                                                    <div class="progress-bar" role="progressbar" 
                                                         style="width: <?php echo $employee['score'] * 100; ?>%;" 
                                                         aria-valuenow="<?php echo $employee['score'] * 100; ?>" 
                                                         aria-valuemin="0" aria-valuemax="100">
                                                        <?php echo round($employee['score'] * 100, 1); ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="mt-3">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check-circle me-2"></i>Assign Selected Employees
                            </button>
                            <a href="../index.php" class="btn btn-secondary ms-2">Cancel</a>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <p>No recommendations available or there was an error processing the request.</p>
                        <p>Error: <?php echo $output; ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../footer.php'; ?>