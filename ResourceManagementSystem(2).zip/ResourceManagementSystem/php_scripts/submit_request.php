<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['role'] == 'project_manager') {
    $project_name = $conn->real_escape_string($_POST['project_name']);
    $skills = $conn->real_escape_string(implode(',', $_POST['skills']));
    $employees_needed = (int)$_POST['employees_needed'];
    $duration = (int)$_POST['duration'];
    $manager_id = $_SESSION['user_id'];
    
    $sql = "INSERT INTO project_requests (project_name, manager_id, required_skills, employees_needed, duration) 
            VALUES ('$project_name', $manager_id, '$skills', $employees_needed, $duration)";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Project request submitted successfully!";
    } else {
        $_SESSION['error'] = "Error submitting request: " . $conn->error;
    }
    
    header("Location: ../index.php");
    exit();
} else {
    header("Location: ../login.php");
    exit();
}
?>