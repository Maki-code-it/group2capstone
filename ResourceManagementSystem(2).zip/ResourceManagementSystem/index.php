<?php
include 'config.php';

// Check user login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Get stats based on user role
if ($user_role == 'hr_admin') {
    $pending_requests = $conn->query("SELECT COUNT(*) as count FROM project_requests WHERE status = 'pending'")->fetch_assoc()['count'];
    $total_employees = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'employee'")->fetch_assoc()['count'];
    $active_projects = $conn->query("SELECT COUNT(DISTINCT request_id) as count FROM project_assignments pa JOIN project_requests pr ON pa.request_id = pr.id WHERE pr.status = 'approved'")->fetch_assoc()['count'];
} elseif ($user_role == 'project_manager') {
    $my_requests = $conn->query("SELECT COUNT(*) as count FROM project_requests WHERE manager_id = $user_id")->fetch_assoc()['count'];
    $approved_requests = $conn->query("SELECT COUNT(*) as count FROM project_requests WHERE manager_id = $user_id AND status = 'approved'")->fetch_assoc()['count'];
    $pending_requests = $conn->query("SELECT COUNT(*) as count FROM project_requests WHERE manager_id = $user_id AND status = 'pending'")->fetch_assoc()['count'];
} elseif ($user_role == 'employee') {
    $my_projects = $conn->query("SELECT COUNT(*) as count FROM project_assignments WHERE employee_id = $user_id")->fetch_assoc()['count'];
    $certificates = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE employee_id = $user_id")->fetch_assoc()['count'];
}
?>
<?php include 'header.php'; ?>

<?php if ($user_role == 'hr_admin'): ?>
    <h2 class="mb-4"><i class="fas fa-tachometer-alt me-2"></i>HR Admin Dashboard</h2>
    
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $pending_requests; ?></h5>
                        <small>Pending Requests</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $total_employees; ?></h5>
                        <small>Total Employees</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-tasks fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $active_projects; ?></h5>
                        <small>Active Projects</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-8 mb-4">
            <div class="blue-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-list-alt me-2"></i>Recent Project Requests</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Project Name</th>
                                    <th>Manager</th>
                                    <th>Skills Required</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT pr.*, u.name as manager_name 
                                        FROM project_requests pr 
                                        JOIN users u ON pr.manager_id = u.id 
                                        ORDER BY pr.created_at DESC LIMIT 5";
                                $result = $conn->query($sql);
                                
                                if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                        $status_class = $row['status'] == 'pending' ? 'warning' : ($row['status'] == 'approved' ? 'success' : 'secondary');
                                        echo "<tr>
                                                <td>{$row['project_name']}</td>
                                                <td>{$row['manager_name']}</td>
                                                <td><span class='badge bg-primary'>{$row['required_skills']}</span></td>
                                                <td><span class='badge bg-$status_class'>{$row['status']}</span></td>
                                                <td>
                                                    <a href='php_scripts/review_request.php?request_id={$row['id']}' class='btn btn-sm btn-primary'>Review</a>
                                                </td>
                                            </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='5' class='text-center'>No project requests found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="blue-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="create_user.php" class="btn btn-primary mb-2">
                            <i class="fas fa-plus me-2"></i>Create New User
                        </a>
                        <a href="#" class="btn btn-outline-primary mb-2">
                            <i class="fas fa-download me-2"></i>Generate Report
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php elseif ($user_role == 'project_manager'): ?>
    <h2 class="mb-4"><i class="fas fa-tachometer-alt me-2"></i>Project Manager Dashboard</h2>
    
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-paper-plane fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $my_requests; ?></h5>
                        <small>My Requests</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $approved_requests; ?></h5>
                        <small>Approved Requests</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $pending_requests; ?></h5>
                        <small>Pending Requests</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="blue-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-paper-plane me-2"></i>Submit New Project Request</h5>
                </div>
                <div class="card-body">
                    <form action="php_scripts/submit_request.php" method="POST">
                        <div class="mb-3">
                            <label for="project_name" class="form-label">Project Name</label>
                            <input type="text" class="form-control" id="project_name" name="project_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="skills" class="form-label">Required Skills</label>
                            <div class="skill-tags-container border rounded p-2">
                                <div class="skill-tags mb-2"></div>
                                <input type="text" class="form-control skill-input" placeholder="Type skill and press Enter">
                            </div>
                            <small class="form-text text-muted">Press Enter or comma to add multiple skills</small>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="employees_needed" class="form-label">Employees Needed</label>
                                <input type="number" class="form-control" id="employees_needed" name="employees_needed" min="1" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="duration" class="form-label">Duration (days)</label>
                                <input type="number" class="form-control" id="duration" name="duration" min="1" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-paper-plane me-2"></i>Submit Request
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="blue-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-history me-2"></i>My Recent Requests</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Project Name</th>
                                    <th>Skills Required</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM project_requests WHERE manager_id = $user_id ORDER BY created_at DESC LIMIT 5";
                                $result = $conn->query($sql);
                                
                                if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                        $status_class = $row['status'] == 'pending' ? 'warning' : ($row['status'] == 'approved' ? 'success' : 'secondary');
                                        echo "<tr>
                                                <td>{$row['project_name']}</td>
                                                <td><span class='badge bg-primary'>{$row['required_skills']}</span></td>
                                                <td><span class='badge bg-$status_class'>{$row['status']}</span></td>
                                                <td>" . date('M j, Y', strtotime($row['created_at'])) . "</td>
                                            </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4' class='text-center'>No project requests submitted yet</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php elseif ($user_role == 'employee'): ?>
    <h2 class="mb-4"><i class="fas fa-tachometer-alt me-2"></i>Employee Dashboard</h2>
    
    <div class="row mb-4">
        <div class="col-md-6 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-briefcase fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $my_projects; ?></h5>
                        <small>My Projects</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-certificate fa-2x"></i>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo $certificates; ?></h5>
                        <small>Certificates</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="blue-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-user-edit me-2"></i>Update My Profile</h5>
                </div>
                <div class="card-body">
                    <form action="php_scripts/update_profile.php" method="POST">
                        <?php
                        $sql = "SELECT * FROM employees WHERE user_id = $user_id";
                        $result = $conn->query($sql);
                        $profile = $result->fetch_assoc();
                        ?>
                        <div class="mb-3">
                            <label for="skills" class="form-label">My Skills</label>
                            <div class="skill-tags-container border rounded p-2">
                                <div class="skill-tags mb-2">
                                    <?php
                                    if (!empty($profile['skills'])) {
                                        $skills = explode(',', $profile['skills']);
                                        foreach ($skills as $skill) {
                                            $skill = trim($skill);
                                            echo "<span class='skill-tag badge bg-primary me-1 mb-1'>$skill
                                                    <input type='hidden' name='skills[]' value='$skill'>
                                                    <button type='button' class='btn-close btn-close-white ms-1' style='font-size: 0.6rem'></button>
                                                  </span>";
                                        }
                                    }
                                    ?>
                                </div>
                                <input type="text" class="form-control skill-input" placeholder="Type skill and press Enter">
                            </div>
                            <small class="form-text text-muted">Press Enter or comma to add multiple skills</small>
                        </div>
                        <div class="mb-3">
                            <label for="education" class="form-label">Education</label>
                            <textarea class="form-control" id="education" name="education" rows="2"><?php echo $profile['education'] ?? ''; ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-save me-2"></i>Update Profile
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="blue-card card mt-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-upload me-2"></i>Upload Certificate</h5>
                </div>
                <div class="card-body">
                    <form action="php_scripts/upload_certificate.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="certificate" class="form-label">Select Certificate (PDF or Image)</label>
                            <input type="file" class="form-control" id="certificate" name="certificate" accept=".pdf,.jpg,.jpeg,.png" required>
                        </div>
                        <button type="submit" class="btn btn-outline-primary w-100">
                            <i class="fas fa-upload me-2"></i>Upload Certificate
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="blue-card card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-briefcase me-2"></i>My Project Assignments</h5>
                </div>
                <div class="card-body">
                    <?php
                    $sql = "SELECT pa.*, pr.project_name, pr.required_skills, pr.duration 
                            FROM project_assignments pa 
                            JOIN project_requests pr ON pa.request_id = pr.id 
                            WHERE pa.employee_id = $user_id 
                            ORDER BY pa.assigned_at DESC";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<div class='project-item mb-3 p-3 border rounded'>
                                    <h6>{$row['project_name']}</h6>
                                    <div class='d-flex justify-content-between text-muted small mb-2'>
                                        <span><i class='fas fa-cogs me-1'></i>{$row['required_skills']}</span>
                                        <span><i class='fas fa-calendar me-1'></i>{$row['duration']} days</span>
                                    </div>
                                    <div class='text-muted small'>
                                        <i class='fas fa-clock me-1'></i>Assigned on " . date('M j, Y', strtotime($row['assigned_at'])) . "
                                    </div>
                                </div>";
                        }
                    } else {
                        echo "<p class='text-center text-muted'>No project assignments yet</p>";
                    }
                    ?>
                </div>
            </div>
            
            <div class="blue-card card mt-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-certificate me-2"></i>My Certificates</h5>
                </div>
                <div class="card-body">
                    <?php
                    $sql = "SELECT * FROM certificates WHERE employee_id = $user_id ORDER BY uploaded_at DESC";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $filename = basename($row['file_path']);
                            echo "<div class='certificate-item mb-2 p-2 border rounded d-flex justify-content-between align-items-center'>
                                    <div>
                                        <i class='fas fa-file-pdf text-danger me-2'></i>
                                        <span>" . substr($filename, 0, 30) . (strlen($filename) > 30 ? '...' : '') . "</span>
                                    </div>
                                    <a href='{$row['file_path']}' class='btn btn-sm btn-outline-primary' download>
                                        <i class='fas fa-download'></i>
                                    </a>
                                </div>";
                        }
                    } else {
                        echo "<p class='text-center text-muted'>No certificates uploaded yet</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php include 'footer.php'; ?>